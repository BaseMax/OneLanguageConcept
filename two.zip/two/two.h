#pragma once
#include "tok.h"
void statement(Tokenizer *t);
